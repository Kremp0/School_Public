/******************************************************************************
 * Laborator 01 - Zaklady pocitacove grafiky - IZG
 * ihulik@fit.vutbr.cz
 *
 * $Id: $
 * 
 * Popis: Hlavicky funkci pro funkce studentu
 *
 * Opravy a modifikace:
 * -
 */

#include "student.h"
#include "globals.h"

#include <time.h>

/******************************************************************************
 ******************************************************************************
 Funkce vraci pixel z pozice x, y. Je nutne hlidat frame_bufferu, pokud 
 je dana souradnice mimo hranice, funkce vraci barvu (0, 0, 0).
 Ukol za 0.5 bodu */
S_RGBA getPixel(int x, int y)
{
	if (x >= 0 && x < width && y >= 0 && y < height)
	{
		return frame_buffer[y * width + x];
	}
	// todo
	return makeBlackColor();
}

/******************************************************************************
 ******************************************************************************
 Funkce vlozi pixel na pozici x, y. Je nutne hlidat frame_bufferu, pokud 
 je dana souradnice mimo hranice, funkce neprovadi zadnou zmenu.
 Ukol za 0.5 bodu */
void putPixel(int x, int y, S_RGBA color)
{
	if (x >= 0 && x < width && y >= 0 && y < height) 
	{
		frame_buffer[y * width + x] = color;
	}
	// todo
}

/******************************************************************************
 ******************************************************************************
 Funkce prevadi obrazek na odstiny sedi. Vyuziva funkce GetPixel a PutPixel.
 Ukol za 1 bod. */
void grayScale()
{
	int i;
	int j;

	for (j = 0; j < height; j++) 
	{
		for (i = 0; i < width; i++) 
		{
			float gray = getPixel(i, j).red * 0.299 + getPixel(i, j).green * 0.587 + getPixel(i, j).blue * 0.114;

			S_RGBA farba;

			farba.blue = farba.green = farba.red = ROUND(gray);

			putPixel(i, j, farba);
		}
	}

	// todo
}

int StrictNumber(int num)
{
	if (num < 0)
		return 0;
	else if (num > 255)
		return 255;

	return num;
}
/******************************************************************************
 ******************************************************************************
 Funkce prevadi obrazek na cernobily pomoci algoritmu distribuce chyby.
 Ukol za 1 bod */
void errorDistribution()
{
	int i, j;
	int y, x;
	int Threshold = 120;
	int chyba;
	S_RGBA farba;

	/* Prevedeme obrazek na grayscale */
	grayScale();

	/* Projdeme vsechny pixely obrazku */
	for (y = 0; y < height; ++y)
		for (x = 0; x < width; ++x)
		{
			/* Nacteme soucasnou barvu */
			S_RGBA color = getPixel(x, y);

			/* Porovname hodnotu cervene barevne slozky s prahem.
			   Muzeme vyuzit jakoukoli slozku (R, G, B), protoze
			   obrazek je sedotonovy, takze R=G=B */
			if (color.red > Threshold) { //priratam getPixel + E
				chyba = color.red - 255;
				farba = color;

				//Zakladne
				//farba.red = StrictNumber(color.red + chyba);
				putPixel(x, y, COLOR_WHITE);

				//X+1, Y
				color = getPixel(x + 1, y);
				farba.red = farba.green = farba.blue = StrictNumber(color.red + ROUND(3.0/8.0 * chyba));
				putPixel(x + 1, y, farba);

				//X+1, Y+1
				color = getPixel(x + 1, y + 1);
				farba.red = farba.green = farba.blue = StrictNumber(color.red + ROUND(1.0/4.0 * chyba));
				putPixel(x + 1, y + 1, farba);

				//X, Y+1
				color = getPixel(x, y + 1);
				farba.red = farba.green = farba.blue = StrictNumber(color.red + ROUND(3.0/8.0 * chyba));
				putPixel(x, y + 1, farba);
			}	
			else {
				chyba = color.red;
				farba = color;

				//Zakladne
				//farba.red = StrictNumber(color.red + chyba);
				putPixel(x, y, COLOR_BLACK);

				//X+1, Y
				color = getPixel(x + 1, y);
				farba.red = farba.green = farba.blue = StrictNumber(color.red + ROUND(3.0/8.0 * chyba));
				putPixel(x + 1, y, farba);

				//X+1, Y+1
				color = getPixel(x + 1, y + 1);
				farba.red = farba.green = farba.blue = StrictNumber(color.red + ROUND(1.0/4.0 * chyba));
				putPixel(x + 1, y + 1, farba);

				//X, Y+1
				color = getPixel(x, y + 1);
				farba.red = farba.green = farba.blue = StrictNumber(color.red + ROUND(3.0/8.0 * chyba));
				putPixel(x, y + 1, farba);
			}	
		}

	// todo
}


/******************************************************************************
 ******************************************************************************
 Funkce prevadi obrazek na cernobily pomoci metody prahovani.
 Demonstracni funkce */
void thresholding(int Threshold)
{
	int y, x;

	/* Prevedeme obrazek na grayscale */
	grayScale();

	/* Projdeme vsechny pixely obrazku */
	for (y = 0; y < height; ++y)
		for (x = 0; x < width; ++x)
		{
			/* Nacteme soucasnou barvu */
			S_RGBA color = getPixel(x, y);

			/* Porovname hodnotu cervene barevne slozky s prahem.
			   Muzeme vyuzit jakoukoli slozku (R, G, B), protoze
			   obrazek je sedotonovy, takze R=G=B */
			if (color.red > Threshold)
				putPixel(x, y, COLOR_WHITE);
			else
				putPixel(x, y, COLOR_BLACK);
		}
}

/******************************************************************************
 ******************************************************************************
 Funkce prevadi obrazek na cernobily pomoci nahodneho rozptyleni. 
 Vyuziva funkce GetPixel, PutPixel a GrayScale.
 Demonstracni funkce. */
void randomDithering()
{
	int y, x;

	/* Prevedeme obrazek na grayscale */
	grayScale();

	/* Inicializace generatoru pseudonahodnych cisel */
	srand((unsigned int)time(NULL));

	/* Projdeme vsechny pixely obrazku */
	for (y = 0; y < height; ++y)
		for (x = 0; x < width; ++x)
		{
			/* Nacteme soucasnou barvu */
			S_RGBA color = getPixel(x, y);
			
			/* Porovname hodnotu cervene barevne slozky s nahodnym prahem.
			   Muzeme vyuzit jakoukoli slozku (R, G, B), protoze
			   obrazek je sedotonovy, takze R=G=B */
			if (color.red > rand()%255)
			{
				putPixel(x, y, COLOR_WHITE);
			}
			else
				putPixel(x, y, COLOR_BLACK);
		}
}
/*****************************************************************************/
/*****************************************************************************/